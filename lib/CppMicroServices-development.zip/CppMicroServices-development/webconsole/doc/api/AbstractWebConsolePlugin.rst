AbstractWebConsolePlugin
------------------------

.. doxygenclass:: cppmicroservices::AbstractWebConsolePlugin
