SimpleWebConsolePlugin
----------------------

.. doxygenclass:: cppmicroservices::SimpleWebConsolePlugin
