WebConsoleVariableResolver
--------------------------

.. doxygenstruct:: cppmicroservices::WebConsoleVariableResolver
