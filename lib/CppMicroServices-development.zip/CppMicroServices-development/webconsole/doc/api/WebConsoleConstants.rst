WebConsoleConstants
-------------------

.. doxygenstruct:: cppmicroservices::WebConsoleConstants
