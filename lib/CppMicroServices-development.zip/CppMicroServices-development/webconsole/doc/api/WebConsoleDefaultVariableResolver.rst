WebConsoleDefaultVariableResolver
---------------------------------

.. doxygenclass:: cppmicroservices::WebConsoleDefaultVariableResolver
