Screenshots
===========

.. figure:: img/bundles.*
   :class: screenshot

   A list of all installed bundles.

.. figure:: img/bundle.*
   :class: screenshot

   Detailed bundle view.

.. figure:: img/resources.*
   :class: screenshot

   Browse and download bundle resources.

.. figure:: img/service_interface.*
   :class: screenshot

   Detailed view on a service interface and registered services implementing it.