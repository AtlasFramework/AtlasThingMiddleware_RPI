Legal
=====

Copyright
---------

.. literalinclude:: ../../COPYRIGHT

License
-------

.. literalinclude:: ../../LICENSE
